let test = document.createElement('h2');
test.textContent = "The js is working";
document.body.appendChild(test);
